import { useState, useEffect } from "react";
import { FaXTwitter, FaLinkedinIn, FaBehance } from "react-icons/fa6";
import { FiMail } from "react-icons/fi";
import "./App.css";
import "react-clock/dist/Clock.css";
import ExperienceTimeline from "./components/ExperienceTimeline";
import ModernCards from "./components/MordernCards";
import EnhancedContactCard from "./components/GetInTouchCard";

type Theme = "light" | "dark";

const App: React.FC = () => {
  const [theme, setTheme] = useState<Theme>("dark");

  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
  }, [theme]);

  const toggleTheme = () => setTheme((t) => (t === "dark" ? "light" : "dark"));
  const [value, setValue] = useState(new Date());

  useEffect(() => {
    const interval = setInterval(() => setValue(new Date()), 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <main className="cv">
      {/* Header */}
      <header className="cv__header">
        <div className="avatar">
          <img
            className="avatar"
            src="/IMG_2568.png"
            alt="Parmeshwara Joga"
            width={40}
            height={40}
          />
        </div>
        <div>
          <div>Parmeshwara Joga</div>
          <p className="subtitle">Full Stack Developer</p>
        </div>
        <button onClick={toggleTheme} className="theme-btn">
          Switch Theme
        </button>
      </header>
      <div className="divider"></div>

      {/* Grid */}
      <section className="cv__grid">
        {/* Clock */}
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            gap: "1rem",
          }}
        >
          <div>
            <ModernCards />

            <EnhancedContactCard />
          </div>

          {/* Experience & Education */}
          <article className="card xp">
            <div className="card-header">
              <div>Experience & Education</div>
            </div>
            <ExperienceTimeline />
          </article>
        </div>

        {/* Projects */}
        <article className="card projects">
          <div className="card-header">
            <div>Projects</div>
          </div>
          <ul>
            <li>
              <span className="thumb fusion" />
              <div>
                <b>XFlow Platform</b>
                <small>
                  Governance-driven data lineage tool using React & Python.
                </small>
              </div>
            </li>
            <li>
              <span className="thumb swoosh" />
              <div>
                <b>Divi's Shipping Portal</b>
                <small>React + NestJS based logistics & tracking app.</small>
              </div>
            </li>
            <li>
              <span className="thumb publication" />
              <div>
                <b>Fintech Mobile App</b>
                <small>
                  Flutter + FastAPI, ML-based PDF extraction & animations.
                </small>
              </div>
            </li>
          </ul>
        </article>

        {/* Get in Touch */}
        <article className="card socials">
          <div className="card-header">
            <div>Get in touch</div>
          </div>
          <div className="social-row">
            <a
              href="https://twitter.com/Param07"
              target="_blank"
              rel="noopener"
            >
              <FaXTwitter />
            </a>
            <a
              href="https://www.linkedin.com/in/parmeshwar-joga-958387193/"
              target="_blank"
              rel="noopener"
            >
              <FaLinkedinIn />
            </a>
            <a href="https://www.behance.net/" target="_blank" rel="noopener">
              <FaBehance />
            </a>
            <a href="mailto:parmeshwar5jan@gmail.com">
              <FiMail />
            </a>
          </div>
        </article>

        {/* Latest Work */}
        <article className="card latest">
          <div className="latest__bar">
            <div>Latest Work</div>
            <a
              href="http://xtrack.divislabs.com/"
              target="_blank"
              rel="noopener"
            >
              Divis Shipping Portal ↗︎
            </a>
          </div>
          <div className="device-mock" />
        </article>

        {/* Side Projects */}
        <article className="card side-projects">
          <div className="card-header">
            <div>Publications</div>
          </div>
          <ul>
            <li>
              Dec 2022 <b>ISDA’22</b> – Comparative Analysis of ML Models
            </li>
            <li>
              Dec 2022 <b>ICIET-2022</b> – Voice Notepad for Smart Healthcare
            </li>
          </ul>
        </article>

        {/* Years of Experience */}
        <article className="card years">
          <div>Years of Experience</div>
          <p className="big-num">2</p>
        </article>

        {/* CV */}
        <article className="card cv">
          <div>CV</div>
          <a href="/PARMESHWARA-JOGA.pdf" target="_blank" className="cta">
            View
          </a>
          <a href="/PARMESHWARA-JOGA.pdf" download className="cta outline">
            Download
          </a>
        </article>
      </section>
    </main>
  );
};

export default App;
